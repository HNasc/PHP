<center><footer class="container-fluid text-center">
		<p>Scamboo® <br/>
		<i>Desenvolvido por:<br/>Dhuli Gabriele & Endriu Gabriel</i><br>
        <i>Dhuli: dgdksilva@restinga.ifrs.edu.br</i><br>
        <i>Endriu: endriugdksilva@restinga.ifrs.edu.br</i></p>
	</footer></center>