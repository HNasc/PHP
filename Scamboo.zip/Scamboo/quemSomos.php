<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <link href="css/style.css" rel="stylesheet" type="text/css"/>
</head>
<body>

<div class="panel panel-default">
<center><h1>Quem Somos!</h1></center>
  <div class="panel-body">
  <center><h2>Este trabalho foi desenvolvido para a conclusão do técnico em Informática <br>
   para Internet do IFRS-Campus Restinga. Ele tem como objetivo a troca de produtos <br>
    sem o uso de dinheiro tornam possivel a aquisição e desprendimento de produtos. <br>
    Buscamos focar em um sistema regional onde o usuário só irá interagir com gaúchos <br>
    e assim facilitar a não utilização de frete para que não haja gastos para os usuários.</h2></center>
</div>
</div>
<div class="panel panel-default">
<center><h1>Colaboradores</h1></center>
  <div class="panel-body">
  <h2></h2>
</div>
</div>  
</body>
</html>
