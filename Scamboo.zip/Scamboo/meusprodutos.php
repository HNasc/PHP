<!DOCTYPE html>
<html>
<head>
<title>Scamboo</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <link href="css/style.css" rel="stylesheet" type="text/css"/>
</head>
<body>

       
       <!-- #region Conteudo -->
<div class="container text-center"> 
  <h3>Meus Produtos</h3><br>
	<div class="row">
	<?php 
		include 'Consulta/conProdutos.php'
	?>
	</div>
</div><br>
<!-- #endregion -->

<!-- #region Modal Cadastro de Produtos -->
<div class="modal fade" id="cadastroProdutosModal" role="dialog">
		<div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-header bg-primary">
			<button type="button" class="close" data-dismiss="modal">&times;</button>
			<h4 class="modal-title"><center>Cadastro de Produtos</center></h4>
			</div>
			<div class="modal-body">
				<IFRAME src="cadastroProdutosForm.php" width="550" height="540" scrolling="yes" frameborder="0"></IFRAME>
				<!-- <p>NUM SEI</p> -->
			</div>
		</div>
		
		</div>
	</div>
<!-- #endregion -->
</body>
</html>
