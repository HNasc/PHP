<!DOCTYPE html>
<html>
<head>
    <title>Scamboo | Detalhes do Produto</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <link href="css/detalheProduto.css" rel="stylesheet" type="text/css"/>
</head>
<body>
    <div class="produtos">
        <ul>
            <li class="scb-item">
                <div class="scb-prod-col-1">
                    <div class="scb-prod-image">
                        <div class="scb-prod-image-box">
                            <img class="image" src="Consulta/imgProduto/016bd8f8969dae1193cfd2c5431318f6.jpg" alt="[Satanzinho thumb]" title="Satanzinho thumb" />
                        </div>
                    </div>
                </div>
                <div class="scb-prod-col-2">
                    <div class="scb-prod-col-2-title">
                        <h3>asgadghadgadg</h3>
                        <div class="scb-prod-col-2-info">
                            asfadgafafasfasasdasdsad<br/>
                            ajshdoahsiofsafiajsfaskfa
                        </div>
                    </div>
                </div>
                <div class="scb-prod-col-3">
                    <button type="button" class="btn btn-xs btn-primary">Trocar</button><br/>
                </div>
                <div class="scb-prod-col-4">
                    Hoje às 08:00
                </div>
            </li>
                <li class="scb-item">
                <div class="scb-prod-col-1">
                    <div class="scb-prod-image">
                        <div class="scb-prod-image-box">
                            <img class="image" src="Consulta/imgProduto/016bd8f8969dae1193cfd2c5431318f6.jpg" alt="[Satanzinho thumb]" title="Satanzinho thumb" />
                        </div>
                    </div>
                </div>
                <div class="scb-prod-col-2">
                    <div class="scb-prod-col-2-title">
                        <h3>asgadghadgadg</h3>
                        <div class="scb-prod-col-2-info">
                            asfadgafafasfasasdasdsad<br/>
                            ajshdoahsiofsafiajsfaskfa
                        </div>
                    </div>
                </div>
                <div class="scb-prod-col-3">
                    <button type="button" class="btn btn-xs btn-primary">Trocar</button><br/>
                </div>
                <div class="scb-prod-col-4">
                    Hoje às 08:00
                </div>
            </li>
        </ul>
    </div>
            <!-- <div class="scb-prod-col-1">
                <img src="Consulta/imgProduto/3b6bfa129fcae85c75f69aa54c7c3649.jpg" alt="[Satanzinho thumb]" title="Satanzinho thumb" />
            </div>
            <div class="scb-prod-col-1">
                <img src="Consulta/imgProduto/1259cbe2c80d346a7f7300010e4d69ac.jpg" alt="[Satanzinho thumb]" title="Satanzinho thumb" width="30%" height="30%" />
            </div>
            <div class="scb-prod-col-1">
                <img src="Consulta/imgProduto/a2662186d4cdb3a466751c9e5d62d266.jpg" alt="[Satanzinho thumb]" title="Satanzinho thumb" width="30%" height="30%"/>
            </div>
        
        </div> -->

</body>
</html>