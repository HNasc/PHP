<!-- #region Rodapé -->
<footer class="container-fluid text-center">
		<p>Scamboo® <br/>
		<i>Desenvolvido por:<br/>Dhuli Gabriele & Endriu Gabriel</i></p>
	</footer>
<!-- #endregion -->