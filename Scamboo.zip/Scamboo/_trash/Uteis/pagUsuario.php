<!DOCTYPE html>
<html>
<head>
<title>SCAMBOO</title>
<meta charset="utf-8">
<link href="css/style.css" rel="stylesheet" type="text/css"/>
</head>
<body>
	<h1>helloooo</h1>
<div id='footer'>			<!-- RODAPÉ -->
Scamboo® <br/>
<i>Desenvolvido por:<br/>Dhuli Gabriele & Endriu Gabriel</i>
</div>
</body>
</html>